Husk at det er i mm

1,3 meter = 1,300mm


https://mikk800t.github.io/Hovedside.html
